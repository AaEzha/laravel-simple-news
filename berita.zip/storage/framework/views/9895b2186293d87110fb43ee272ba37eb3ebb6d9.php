<?php $__env->startSection('main-content'); ?>

    <div class="pb-5">
        <p class="h1 font-weight-bold text-primary"><?php echo e($article->title); ?></p>
        <p>Ditulis oleh <span class="text-primary"><?php echo e($article->user->full_name); ?></span>, <?php echo e((is_null($article->updated_at)) ? $article->created_at->format('d F Y, H:i') : $article->updated_at->format('d F Y, H:i')); ?></p>
        <hr>
        <div class="pb-3">
            <?php echo $article->content; ?>

        </div>
        <p>Category <span class="text-info"><?php echo e($article->category->name); ?></span></p>
    </div>

    <div class="font-weight-bold pb-3"><a href="<?php echo e(route('blog')); ?>">Kembali ke  Homepage</a></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/read.blade.php ENDPATH**/ ?>