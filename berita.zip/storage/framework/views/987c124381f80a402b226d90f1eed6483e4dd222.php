<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

    <!-- Main Content goes here -->

    <a href="<?php echo e(route('article.create')); ?>" class="btn btn-primary mb-3">New Article</a>
    <a href="<?php echo e(route('article.export-excel')); ?>" class="btn btn-secondary mb-3"><i class="fa fa-file-excel" aria-hidden="true"></i> Export to Excel</a>
    <a href="<?php echo e(route('article.export-pdf')); ?>" class="btn btn-secondary mb-3"><i class="fa fa-file-pdf" aria-hidden="true"></i> Export to PDF</a>

    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered table-stripped">
        <thead>
            <tr>
                <th>No</th>
                <th>Article</th>
                <th>Slug</th>
                <th>Category</th>
                <th>Writer</th>
                <th>#</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td scope="row"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($article->title); ?></td>
                    <td><?php echo e($article->slug); ?></td>
                    <td><?php echo e($article->category->name); ?></td>
                    <td><?php echo e($article->user->full_name); ?></td>
                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('article.edit', $article->id)); ?>" class="btn btn-sm btn-primary mr-2">Edit</a>
                            <form action="<?php echo e(route('article.destroy', $article->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete this?')">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center font-weight-bold p-5 h4">No article yet. Mind to <a href="<?php echo e(route('article.create')); ?>">create one</a>?</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($articles->links()); ?>


    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/article/index.blade.php ENDPATH**/ ?>