<table>
    <thead>
        <tr>
            <th>Title</th>
            <th>Slug</th>
            <th>Category</th>
            <th>Content</th>
            <th>Writer</th>
            <th>User Views</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($article->title); ?></td>
                <td><?php echo e($article->slug); ?></td>
                <td><?php echo e($article->category->name); ?></td>
                <td><?php echo $article->content; ?></td>
                <td><?php echo e($article->user->name); ?></td>
                <td><?php echo e($article->user_views); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No article yet</td>
            </tr>
        <?php endif; ?>
        <tr>
            <td colspan="6"></td>
        </tr>
        <tr>
            <td colspan="6">Printed at : <?php echo e($time); ?></td>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\berita\resources\views/article/export.blade.php ENDPATH**/ ?>